Cara install :

- pkg update
- pkg upgrade
- pkg install python2 git -y
- git clone https://github.com/Bl4ckDr460n/ScanIp
- cd ScanIp
- python2 scanip.py


